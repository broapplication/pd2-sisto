package it.polito.pd2.WF.sol2;

import it.polito.pd2.WF.ActionReader;

public interface Action extends ActionReader {
}