package it.polito.pd2.WF.sol2;

import it.polito.pd2.WF.ProcessActionReader;

public interface ProcessAction extends ProcessActionReader {
}
