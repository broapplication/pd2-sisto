package it.polito.pd2.WF.sol2;

import it.polito.pd2.WF.SimpleActionReader;

public interface SimpleAction extends SimpleActionReader {

}
