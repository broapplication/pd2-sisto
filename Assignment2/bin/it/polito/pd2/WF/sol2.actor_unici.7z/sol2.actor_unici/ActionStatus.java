package it.polito.pd2.WF.sol2;

import it.polito.pd2.WF.ActionStatusReader;

public interface ActionStatus extends ActionStatusReader {
}