package it.polito.pd2.WF.sol2;

import java.util.Calendar;

import it.polito.pd2.WF.ActionReader;
import it.polito.pd2.WF.Actor;

public class ActionStatusImpl implements ActionStatus {
	protected ActionReader action;
	protected Actor actor;
	protected Calendar terminationTime;
	
	protected void initActionStatus(ActionReader action, Actor actor, Calendar terminationTime) {
		this.action=action;
		this.actor=actor;
		this.terminationTime=terminationTime;
	}
	
	public ActionStatusImpl(ActionReader action) {
		initActionStatus(action, null, null);		
	}
	
	public ActionStatusImpl(ActionReader action,Actor actor) {
		initActionStatus(action, actor, null);
	}
	
	public ActionStatusImpl(ActionReader action,Actor actor,Calendar terminationTime) {
		initActionStatus(action, actor, terminationTime);
	}

	@Override
	public String getActionName() {
		return action.getName();
	}

	@Override
	public Actor getActor() {
		return actor;
	}

	@Override
	public Calendar getTerminationTime() {
		return terminationTime;
	}

	@Override
	public boolean isTakenInCharge() {
		return actor!=null;
	}

	@Override
	public boolean isTerminated() {
		return terminationTime!=null;
	}
	
	public void setActor(Actor actor) {
		this.actor=actor;
	}
	
	public ActionReader getAction() {
		return action;
	}

	public void setAction(ActionReader action) {
		this.action = action;
	}
}
