package it.polito.pd2.WF.sol2;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.xml.sax.SAXException;


import it.polito.pd2.WF.Actor;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.WorkflowMonitor;
import it.polito.pd2.WF.WorkflowReader;

public class WorkflowMonitorImpl implements WorkflowMonitor {	
	private static final String ERROR_ROLE = "error different role";

	private Map<String, WorkflowReader> workflows;
	private Set<ProcessReader> processes;
	private Map<String, Actor> actors;
	private Map<String, Set<ActionStatusImpl>> actorsIdrefs;
	
	public WorkflowMonitorImpl() {
	
		workflows=new LinkedHashMap<String, WorkflowReader>();
		processes=new LinkedHashSet<ProcessReader>();
		actors=new HashMap<String, Actor>();
		actorsIdrefs=new HashMap<String, Set<ActionStatusImpl>>();

	}
	

	private void linkActorToIdrefs(String idref,Actor ar) throws SAXException {
		if(actorsIdrefs.get(idref)==null)
			return;
		for(ActionStatusImpl as: actorsIdrefs.get(idref)) {
			if(!as.getAction().getRole().equals(ar.getRole()))
				throw new SAXException(ERROR_ROLE + " between " +as.getActionName()+" and "+ar.getName());
			as.setActor(ar);
		}

	}
	
	public void addActorLink(String idref, ActionStatusImpl actionStatus) {
		if(!actorsIdrefs.containsKey(idref))
			actorsIdrefs.put(idref, new HashSet<ActionStatusImpl>());
		actorsIdrefs.get(idref).add(actionStatus);

	}
	
	
	public void addActor(String id,Actor actor) throws SAXException {
		actors.put(id, actor);
		linkActorToIdrefs(id, actor);
	}
	
	public void addProcess(ProcessReader process) {
		processes.add(process);
	}
	
	public void addWorkflow(String name, WorkflowReader workflow) {
		workflows.put(name, workflow);
	}
	

	@Override
	public Set<ProcessReader> getProcesses() {
		return new LinkedHashSet<ProcessReader>(processes);
	}

	@Override
	public WorkflowReader getWorkflow(String name) {
		return workflows.get(name);
	}

	@Override
	public Set<WorkflowReader> getWorkflows() {
		return new LinkedHashSet<WorkflowReader>(workflows.values());
	}
}
