package it.polito.pd2.WF.sol2;

public abstract class Placeholder {
	protected boolean linked;
	
	public boolean isLinked()	{
		return linked;
	}
	
	public abstract void link(Placeholder obj) throws PlaceholderException;
	
	protected void checkClassAndUnlinked(Placeholder objToLink) throws PlaceholderException {
		if(objToLink==null || !objToLink.getClass().equals(this.getClass()))
			throw new PlaceholderException("wrong link (null or invalid type)");
		
		if(isLinked())
			throw new PlaceholderException("placeholder already linked");
	}
}
