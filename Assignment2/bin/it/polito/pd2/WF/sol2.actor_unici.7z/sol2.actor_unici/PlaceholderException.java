package it.polito.pd2.WF.sol2;

public class PlaceholderException extends Exception {

	private static final long serialVersionUID = 7556607139170663677L;
	
	public PlaceholderException() {	}
	
	public PlaceholderException(String message) {
		super(message);
	}
}
