package it.polito.pd2.WF.sol2;

import it.polito.pd2.WF.WorkflowReader;

public interface Workflow extends WorkflowReader {

}
