package it.polito.pd2.WF.sol2;

import it.polito.pd2.WF.ProcessReader;

public interface Process extends ProcessReader {

}
