package it.polito.pd2.WF.sol6.service;

@SuppressWarnings("serial")
public class WorkflowServerException extends Exception {
	
	public WorkflowServerException(String message) {
		super(message);
	}
}
