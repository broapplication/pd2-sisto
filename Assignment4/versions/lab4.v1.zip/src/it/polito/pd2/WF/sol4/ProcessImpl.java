package it.polito.pd2.WF.sol4;

import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.ActionStatusReader;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.WorkflowReader;
import it.polito.pd2.WF.sol4.jaxb.ActionStatusType;
import it.polito.pd2.WF.sol4.jaxb.ProcessType;

@XmlTransient
public class ProcessImpl extends ProcessType implements 
		ProcessReader, Unmarshallable {
	
	@XmlTransient
	private WorkflowImpl workflow;
	
	public ProcessImpl(ProcessReader process, WorkflowImpl workflow) {
		this.workflow=workflow;
		setStartTime((Calendar)process.getStartTime().clone());
		
		List<ActionStatusType> statusList=getStatusList();
		//add action status
		for(ActionStatusReader status : process.getStatus())
			statusList.add(new ActionStatusImpl(status,this));
	}

	public ProcessImpl() {
	}

	@Override
	public WorkflowReader getWorkflow() {
		return workflow;
	}

	@Override
	public List<ActionStatusReader> getStatus() {
		LinkedList<ActionStatusReader> list = new LinkedList<ActionStatusReader>();
		for(ActionStatusType as : getStatusList())
			list.add((ActionStatusReader) as);
		return list;
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		workflow=(WorkflowImpl) parent;
	}

	@Override
	public void afterUnmarshal(Object parent) {
	}

}
