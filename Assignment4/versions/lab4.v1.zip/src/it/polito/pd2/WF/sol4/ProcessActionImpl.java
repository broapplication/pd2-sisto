package it.polito.pd2.WF.sol4;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.ProcessActionReader;
import it.polito.pd2.WF.WorkflowReader;
import it.polito.pd2.WF.sol4.jaxb.ProcessActionType;

@XmlTransient
public class ProcessActionImpl extends ProcessActionType implements
		ProcessActionReader, Unmarshallable {

	public ProcessActionImpl(ProcessActionReader action, WorkflowImpl workflow) {
		if(action==null)
			return;
		setName(action.getName());
		setRole(action.getRole());
		setAutomaticallyIstantiated(action.isAutomaticallyInstantiated());
		enclosingWorkflow=workflow;
		workflow.getMonitor().addWorkflowRef(
				action.getActionWorkflow().getName(), this);
	}

	public ProcessActionImpl() {
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		enclosingWorkflow=(WorkflowReader) parent;
		
	}

	@Override
	public void afterUnmarshal(Object parent) {
		((WorkflowImpl)enclosingWorkflow).getMonitor().addWorkflowRef(
				getActionWorkflow().getName(), this);
		
	}
	

}
