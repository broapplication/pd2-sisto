package it.polito.pd2.WF.sol4;

import java.util.Calendar;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.ActionStatusReader;
import it.polito.pd2.WF.Actor;
import it.polito.pd2.WF.sol4.jaxb.ActionStatusType;
import it.polito.pd2.WF.sol4.jaxb.ActorType;

@XmlTransient
public class ActionStatusImpl extends ActionStatusType implements
ActionStatusReader, Unmarshallable {

	@XmlTransient
	private Actor actor;

	@XmlTransient
	private ProcessImpl process;

	public ActionStatusImpl(ActionStatusReader status, ProcessImpl process) {
		setActionName(status.getActionName());
		this.setProcess(process);
		if(status.isTerminated())
			setTerminationTime((Calendar) status.getTerminationTime().clone());
		if(status.isTakenInCharge()) {
			Actor actor=status.getActor();
			String name=actor.getName();
			String role=actor.getRole();
			ActorType actorT=new ActorType();
			actorT.setName(actor.getName());
			actorT.setRole(actor.getRole());
			setActorT(actorT);
			this.actor=new Actor(name, role);
		}
	}

	public ActionStatusImpl() {
	}

	@Override
	public Actor getActor() {
		return actor;
	}

	@Override
	public boolean isTakenInCharge() {
		return actorT != null;
	}

	@Override
	public boolean isTerminated() {
		return terminationTime != null;
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		setProcess((ProcessImpl) parent);
	}

	@Override
	public void afterUnmarshal(Object parent) {
		if(isTakenInCharge()) {
			ActorType actorT=getActorT();
			actor=new Actor(actorT.getName(), actorT.getRole());
		}		
	}

	public ProcessImpl getProcess() {
		return process;
	}

	public void setProcess(ProcessImpl process) {
		this.process = process;
	}
}
