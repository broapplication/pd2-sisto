package it.polito.pd2.WF.sol4;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.Actor;

@XmlTransient
public class ActorImpl extends Actor {
	public ActorImpl() {
		super(null, null);
	}
}
