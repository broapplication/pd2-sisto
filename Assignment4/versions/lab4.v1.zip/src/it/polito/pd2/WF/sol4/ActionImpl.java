package it.polito.pd2.WF.sol4;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.ActionReader;
import it.polito.pd2.WF.WorkflowReader;
import it.polito.pd2.WF.sol4.jaxb.ActionType;

@XmlTransient
public class ActionImpl extends ActionType 
		implements ActionReader {
	
	@XmlTransient
	protected WorkflowReader enclosingWorkflow;

	@Override
	public boolean isAutomaticallyInstantiated() {
		return super.isAutomaticallyIstantiated();
	}

	@Override
	public WorkflowReader getEnclosingWorkflow() {
		return enclosingWorkflow;
	}


	@Override
	public boolean equals(Object obj) {
		return this.name.equals(((ActionReader)obj).getName());
	}
}
