package it.polito.pd2.WF.sol4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import it.polito.pd2.WF.ActionReader;
import it.polito.pd2.WF.ActionStatusReader;
import it.polito.pd2.WF.Actor;
import it.polito.pd2.WF.ProcessActionReader;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.SimpleActionReader;
import it.polito.pd2.WF.WorkflowMonitorError;
import it.polito.pd2.WF.WorkflowReader;

/**
 * <p>Java class for workflowType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="workflowType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice maxOccurs="unbounded">
 *           &lt;element name="simpleAction" type="{http://www.example.org/wfInfo}simpleActionType"/>
 *           &lt;element name="processAction" type="{http://www.example.org/wfInfo}processActionType"/>
 *         &lt;/choice>
 *         &lt;element name="process" type="{http://www.example.org/wfInfo}processType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="name" use="required" type="{http://www.example.org/wfInfo}idType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "workflowType", propOrder = {
    "actionList",
    "processList"
})
public class WorkflowImpl implements 
		WorkflowReader, Unmarshallable {
	
    @XmlElements({
        @XmlElement(name = "simpleAction", type = SimpleActionImpl.class),
        @XmlElement(name = "processAction", type = ProcessActionImpl.class)
    })
    protected List<ActionImpl> actionList;
    @XmlElement(name = "process", type = ProcessImpl.class)
    protected List<ProcessImpl> processList;
    @XmlAttribute(name = "name", required = true)
    protected String name;


	private static final String ERROR_ROLE = "error different role";

	@XmlTransient
	private Map<String, ActionImpl> actions;
	@XmlTransient
	private Map<String, List<SimpleActionImpl>> actionRefs;
	@XmlTransient
	private WorkflowMonitorImpl monitor;
	

	public WorkflowImpl() {
		this(null,null);
	}
	
	public WorkflowImpl(WorkflowReader workflow, WorkflowMonitorImpl monitor) {
		actionRefs=new HashMap<String, List<SimpleActionImpl>>();
		actions=new LinkedHashMap<String, ActionImpl>();
		this.monitor=monitor;
		if(workflow==null)
			return;
		
		setName(workflow.getName());
		
		List<ActionImpl> actionList=getActionList();
		List<ProcessImpl> processList=getProcessList();
		
		//add actions
		for(ActionReader action : workflow.getActions()) {
			if(action instanceof SimpleActionReader)
				actionList.add(new SimpleActionImpl((SimpleActionReader) action,this));
			else
				actionList.add(new ProcessActionImpl((ProcessActionReader)action,this));
		}
		actionsMapping();
		
		//add processes
		for(ProcessReader process : workflow.getProcesses())
			processList.add(new ProcessImpl(process,this));
	}
	
    public WorkflowImpl(String name) {
		this.name=name;
	}

	/**
     * Gets the value of the actionList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actionList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActionList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SimpleActionType }
     * {@link ProcessActionType }
     * 
     * 
     */
    public List<ActionImpl> getActionList() {
        if (actionList == null) {
            actionList = new ArrayList<ActionImpl>();
        }
        return this.actionList;
    }

    /**
     * Gets the value of the processList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the processList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProcessList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProcessType }
     * 
     * 
     */
    public List<ProcessImpl> getProcessList() {
        if (processList == null) {
            processList = new ArrayList<ProcessImpl>();
        }
        return this.processList;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }


	public void addActionRef(String key,SimpleActionImpl ref) {
		WorkflowMonitorFactoryImpl.addRef(actionRefs, key, ref);
	}
	
	@Override
	public Set<ActionReader> getActions() {
		return new LinkedHashSet<ActionReader>(actions.values());
	}

	@Override
	public Set<ProcessReader> getProcesses() {
		Set<ProcessReader> set = new LinkedHashSet<ProcessReader>();
		for(ProcessImpl p : getProcessList())
			set.add((ProcessReader)p);
		return set;
	}

	@Override
	public ActionReader getAction(String name) {
		return actions.get(name);
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		monitor=(WorkflowMonitorImpl) parent;
	}
	
	private void actionsMapping() {
		//map actions
		for(ActionImpl action:getActionList()) {
			String name=action.getName();
			actions.put(name, action);
			//link to SimpleAction.possibleNextAction in actionRefs
			List<SimpleActionImpl> list = actionRefs.get(name);
			if(list==null)
				continue;
			for(SimpleActionImpl simple : list)
				simple.setPossibleNextAction(action);
		}
	}

	@Override
	public void afterUnmarshal(Object parent) {
		actionsMapping();
		checkRoles();
	}

	private void checkRoles() {
		for(ProcessImpl process : getProcessList())
			for(ActionStatusReader status :process.getStatus()) {
				Actor actor=status.getActor();
				if(actor!=null && !getAction(status.getActionName()).getRole().equals(
						actor.getRole()))
					throw new WorkflowMonitorError(
							ERROR_ROLE + " between " +status.getActionName()+" and "+actor.getName());
			}
	}

	public WorkflowMonitorImpl getMonitor() {
		return monitor;
	}

}
