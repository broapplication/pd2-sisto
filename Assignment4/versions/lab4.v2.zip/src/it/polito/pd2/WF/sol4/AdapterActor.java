package it.polito.pd2.WF.sol4;

import it.polito.pd2.WF.Actor;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class AdapterActor extends XmlAdapter<ActorImpl, Actor> {

	@Override
	public ActorImpl marshal(Actor v) throws Exception {
		return new ActorImpl(v.getName(), v.getRole());
	}

	@Override
	public Actor unmarshal(ActorImpl v) throws Exception {
		return new Actor(v.getName(), v.getRole());
	}

}
