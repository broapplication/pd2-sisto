package it.polito.pd2.WF.sol4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;


import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.WorkflowMonitor;
import it.polito.pd2.WF.WorkflowMonitorError;
import it.polito.pd2.WF.WorkflowReader;
/**
 * <p>Java class for workflowMonitorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="workflowMonitorType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="workflow" type="{http://www.example.org/wfInfo}workflowType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "workflowMonitorType", propOrder = {
		"workflowList"
})
@XmlRootElement(name = "workflowMonitor",namespace="http://www.example.org/wfInfo")
public class WorkflowMonitorImpl implements
		WorkflowMonitor, Unmarshallable {

    @XmlElement(name = "workflow", type = WorkflowImpl.class)
    protected List<WorkflowImpl> workflowList;

	@XmlTransient
	private HashMap<String, WorkflowImpl> workflows;
	@XmlTransient
	private Map<String, List<ProcessActionImpl>> workflowRefs;

	public WorkflowMonitorImpl() {
		this(null);
	}

	public WorkflowMonitorImpl(WorkflowMonitor monitor) throws WorkflowMonitorError {
		workflows=new LinkedHashMap<String, WorkflowImpl>();
		workflowRefs=new HashMap<String, List<ProcessActionImpl>>();
		if(monitor==null)
			return;

		List<WorkflowImpl> workflowList=getWorkflowList();

		//add workflows
		for(WorkflowReader wr : monitor.getWorkflows())
			workflowList.add(new WorkflowImpl(wr,this));

		workflowsMapping();
	}

    /**
     * Gets the value of the workflowList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the workflowList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWorkflowList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WorkflowType }
     * 
     * 
     */
    public List<WorkflowImpl> getWorkflowList() {
        if (workflowList == null) {
            workflowList = new ArrayList<WorkflowImpl>();
        }
        return this.workflowList;
    }


	public void addWorkflowRef(String key, ProcessActionImpl ref) {
		WorkflowMonitorFactoryImpl.addRef(workflowRefs, key, ref);
	}

	@Override
	public Set<WorkflowReader> getWorkflows() {
		Set<WorkflowReader> set=new LinkedHashSet<WorkflowReader>();
		for(WorkflowImpl wf : getWorkflowList())
			set.add((WorkflowReader)wf);
		return set;
	}

	@Override
	public WorkflowReader getWorkflow(String name) {
		return workflows.get(name);
	}

	@Override
	public Set<ProcessReader> getProcesses() {		
		Set<ProcessReader> processes = new LinkedHashSet<ProcessReader>();
		for(WorkflowImpl workflow : workflows.values())
			processes.addAll(workflow.getProcesses());
		return processes;
	}

	@Override
	public void beforeUnmarshal(Object parent) {
	}

	private void workflowsMapping() {
		for(WorkflowImpl wt : getWorkflowList()) {
			String name=wt.getName();
			workflows.put(name, (WorkflowImpl) wt);
			//link to ProcessAction in workflowRefs
			List<ProcessActionImpl> actionList = workflowRefs.get(name);
			if(actionList==null)
				continue;
			for(ProcessActionImpl action : actionList)
				action.setActionWorkflow(wt);
		}
	}

	@Override
	public void afterUnmarshal(Object parent) {
		workflowsMapping();
	}

}
