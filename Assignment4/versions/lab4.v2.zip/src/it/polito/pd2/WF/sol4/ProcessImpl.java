package it.polito.pd2.WF.sol4;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import it.polito.pd2.WF.ActionStatusReader;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.WorkflowReader;

/**
 * <p>Java class for processType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="processType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="actionStatus" type="{http://www.example.org/wfInfo}actionStatusType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="startTime" use="required" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "processType", propOrder = {
    "statusList"
})
public class ProcessImpl implements 
		ProcessReader, Unmarshallable {

    @XmlElement(name = "actionStatus", type = ActionStatusImpl.class)
    protected List<ActionStatusImpl> statusList;
    @XmlAttribute(name = "startTime", required = true)
    @XmlJavaTypeAdapter(AdapterCalendar .class)
    @XmlSchemaType(name = "dateTime")
    protected Calendar startTime;

	@XmlTransient
	private WorkflowImpl workflow;
	
	public ProcessImpl(ProcessReader process, WorkflowImpl workflow) {
		this.workflow=workflow;
		setStartTime((Calendar)process.getStartTime().clone());
		
		List<ActionStatusImpl> statusList=getStatusList();
		//add action status
		for(ActionStatusReader status : process.getStatus())
			statusList.add(new ActionStatusImpl(status,this));
	}

	public ProcessImpl() {
	}


    /**
     * Gets the value of the statusList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statusList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatusList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActionStatusType }
     * 
     * 
     */
    public List<ActionStatusImpl> getStatusList() {
        if (statusList == null) {
            statusList = new ArrayList<ActionStatusImpl>();
        }
        return this.statusList;
    }

    /**
     * Gets the value of the startTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Calendar getStartTime() {
        return startTime;
    }

    /**
     * Sets the value of the startTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartTime(Calendar value) {
        this.startTime = value;
    }

	
	@Override
	public WorkflowReader getWorkflow() {
		return workflow;
	}

	@Override
	public List<ActionStatusReader> getStatus() {
		LinkedList<ActionStatusReader> list = new LinkedList<ActionStatusReader>();
		for(ActionStatusImpl as : getStatusList())
			list.add((ActionStatusReader) as);
		return list;
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		workflow=(WorkflowImpl) parent;
	}

	@Override
	public void afterUnmarshal(Object parent) {
	}

}
