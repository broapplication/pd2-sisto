package it.polito.pd2.WF.sol4;

import java.util.Set;

import it.polito.pd2.WF.ActionReader;
import it.polito.pd2.WF.Actor;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.WorkflowReader;

public final class MyDatatypeConverter {
    public static ActionReader parseActionReader(final String name) {
    	return new ActionReader() {
        		
			@Override
			public boolean isAutomaticallyInstantiated() {
				return false;
			}
			
			@Override
			public String getRole() {
				return null;
			}
			
			@Override
			public String getName() {
				return name;
			}
			
			@Override
			public WorkflowReader getEnclosingWorkflow() {
				return null;
			}
		};
    }
    public static String printActionReader(ActionReader action) {
    	return action.getName();
    }
    
    public static WorkflowReader parseWorkflowReader(final String name) {
    	return new WorkflowReader() {
			@Override
			public Set<ProcessReader> getProcesses() {
				return null;
			}
			
			@Override
			public String getName() {
				return name;
			}
			
			@Override
			public Set<ActionReader> getActions() {
				return null;
			}
			
			@Override
			public ActionReader getAction(String name) {
				return null;
			}
		};
    }
    
    public static String printWorkflowReader(WorkflowReader workflow) {
    	return workflow.getName();
    }
    
    public static Actor parseActor(String name) {
    	return new Actor(name, null);
    }
    
    public static String printActor(Actor actor) {
    	
    	if(actor==null)
    		return null;
    	return actor.getName();
    }
    
}
