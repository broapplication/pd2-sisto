package it.polito.pd2.WF.sol4;

import java.util.Calendar;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.ActionStatusReader;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.sol4.jaxb.ActionStatusType;

@XmlTransient
public class ActionStatusImpl extends ActionStatusType implements
		ActionStatusReader, Unmarshallable {

	@XmlTransient
	private ProcessImpl process;
	
	public ActionStatusImpl(ActionStatusReader status, ProcessImpl process) {
		setActionName(status.getActionName());
		this.setProcess(process);
		if(status.isTerminated())
			setTerminationTime((Calendar) status.getTerminationTime().clone());
		if(status.isTakenInCharge())
			((WorkflowImpl)process.getWorkflow()).getMonitor().addActorRef(
				status.getActor().getName(),this);
	}

	public ActionStatusImpl() {
	}

	@Override
	public boolean isTakenInCharge() {
		return actor != null;
	}

	@Override
	public boolean isTerminated() {
		return terminationTime != null;
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		setProcess((ProcessImpl) parent);
	}

	@Override
	public void afterUnmarshal(Object parent) {
		if(getActor()!=null)
			((WorkflowImpl)((ProcessReader)parent).getWorkflow()).getMonitor().addActorRef(
				getActor().getName(),this);
	}

	public ProcessImpl getProcess() {
		return process;
	}

	public void setProcess(ProcessImpl process) {
		this.process = process;
	}
}
