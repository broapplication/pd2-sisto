package it.polito.pd2.WF.sol4;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.ActionReader;
import it.polito.pd2.WF.SimpleActionReader;
import it.polito.pd2.WF.WorkflowReader;
import it.polito.pd2.WF.sol4.jaxb.SimpleActionType;

@XmlTransient
public class SimpleActionImpl extends SimpleActionType implements
		SimpleActionReader, Unmarshallable {

	public SimpleActionImpl(SimpleActionReader action, WorkflowImpl workflow) {
		if(action==null)
			return;
		setName(action.getName());
		setRole(action.getRole());
		setAutomaticallyIstantiated(action.isAutomaticallyInstantiated());
		enclosingWorkflow=workflow;
		
		List<ActionReader> nextList = getPossibleNextActionList();
		//add next actions
		for(ActionReader next : action.getPossibleNextActions()) {
			String name=next.getName();
			next=new ActionImpl();	//will be replaced after mapping
			((ActionImpl)next).setName(name);
			nextList.add(next);
			workflow.addActionRef(name,this);
		}
		
	}

	public SimpleActionImpl() {
	}

	@Override
	public Set<ActionReader> getPossibleNextActions() {
		return new LinkedHashSet<ActionReader>(possibleNextActionList);
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		enclosingWorkflow=(WorkflowReader) parent;
	}

	@Override
	public void afterUnmarshal(Object parent) {
		//adding pending links to actionRef in eclosingWorkflow
		for(ActionReader a:getPossibleNextActionList())
			((WorkflowImpl)enclosingWorkflow).addActionRef(a.getName(),this);
	}
	
	public void setPossibleNextAction(ActionReader a) {
		possibleNextActionList.set(possibleNextActionList.indexOf(a), a);
		
	}
}
