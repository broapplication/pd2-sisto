package it.polito.pd2.WF.sol4;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;


import it.polito.pd2.WF.ActionStatusReader;
import it.polito.pd2.WF.Actor;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.WorkflowMonitor;
import it.polito.pd2.WF.WorkflowMonitorError;
import it.polito.pd2.WF.WorkflowReader;
import it.polito.pd2.WF.sol4.jaxb.ActorType;
import it.polito.pd2.WF.sol4.jaxb.WorkflowMonitorType;
import it.polito.pd2.WF.sol4.jaxb.WorkflowType;

@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "workflowMonitorType")
@XmlRootElement(name = "workflowMonitor",namespace="http://www.example.org/wfInfo")
public class WorkflowMonitorImpl extends WorkflowMonitorType implements
		WorkflowMonitor, Unmarshallable {
	
	@XmlTransient
	private HashMap<String, WorkflowImpl> workflows;
	@XmlTransient
	private HashMap<String, Actor> actors;
	@XmlTransient
	private Map<String, List<ProcessActionImpl>> workflowRefs;
	@XmlTransient
	private Map<String, List<ActionStatusImpl>> actorRefs;
	@XmlTransient
	private static final String ERROR_ROLE = "error different role";
	
	public WorkflowMonitorImpl() {
		this(null);
	}
	
	public WorkflowMonitorImpl(WorkflowMonitor monitor) throws WorkflowMonitorError {
		workflows=new LinkedHashMap<String, WorkflowImpl>();
		actors=new LinkedHashMap<String, Actor>();
		workflowRefs=new HashMap<String, List<ProcessActionImpl>>();
		actorRefs=new HashMap<String, List<ActionStatusImpl>>();
		if(monitor==null)
			return;
		
		List<WorkflowType> workflowList=getWorkflowList();
		List<ActorType> actorList=getActorList();
		
		//add workflows
		for(WorkflowReader wr : monitor.getWorkflows()) {
			workflowList.add(new WorkflowImpl(wr,this));
			
			//add actors	(key mapping with null objects)
			for(ProcessReader pr : wr.getProcesses())
				for(ActionStatusReader asr: pr.getStatus()) {
					if(!asr.isTakenInCharge())
						continue;
					 Actor actor=asr.getActor();
					 String name=actor.getName();
					 if(!actors.containsKey(name)) {
						 ActorType at=new ActorType();
						 at.setName(name);
						 at.setRole(actor.getRole());
						 actorList.add(at);
						 actors.put(name, null);
					 }
				}
		}
		workflowsMapping();
		actorsMapping();
	}
	
	public void addWorkflowRef(String key, ProcessActionImpl ref) {
		WorkflowMonitorFactoryImpl.addRef(workflowRefs, key, ref);
	}
	
	public void addActorRef(String key, ActionStatusImpl ref) {
		WorkflowMonitorFactoryImpl.addRef(actorRefs, key, ref);
	}

	@Override
	public Set<WorkflowReader> getWorkflows() {
		Set<WorkflowReader> set=new LinkedHashSet<WorkflowReader>();
		for(WorkflowType wf : getWorkflowList())
			set.add((WorkflowReader)wf);
		return set;
	}

	@Override
	public WorkflowReader getWorkflow(String name) {
		return workflows.get(name);
	}

	@Override
	public Set<ProcessReader> getProcesses() {		
		Set<ProcessReader> processes = new LinkedHashSet<ProcessReader>();
		for(WorkflowImpl workflow : workflows.values())
			processes.addAll(workflow.getProcesses());
		return processes;
	}

	@Override
	public void beforeUnmarshal(Object parent) {
	}
	
	private void actorsMapping() {
		for(ActorType at : getActorList()) {
			String name=at.getName();
			String role=at.getRole();
			Actor actor=new Actor(name, role);
			actors.put(name, actor);
			//link to ActionStatus in actorRefs
			List<ActionStatusImpl> statusList = actorRefs.get(name);
			if(statusList==null)
				continue;
			for(ActionStatusImpl status : statusList) {
				if(!status.getProcess().getWorkflow().getAction(status.getActionName()).getRole().equalsIgnoreCase(role))
					throw new WorkflowMonitorError(ERROR_ROLE + " between " +status.getActionName()+" and "+name);
				status.setActor(actor);
			}
		}
	}
	
	private void workflowsMapping() {
		for(WorkflowType wt : getWorkflowList()) {
			String name=wt.getName();
			workflows.put(name, (WorkflowImpl) wt);
			//link to ProcessAction in workflowRefs
			List<ProcessActionImpl> actionList = workflowRefs.get(name);
			if(actionList==null)
				continue;
			for(ProcessActionImpl action : actionList)
				action.setActionWorkflow((WorkflowReader)wt);
		}
	}

	@Override
	public void afterUnmarshal(Object parent) {
		actorsMapping();
		workflowsMapping();
	}

}
