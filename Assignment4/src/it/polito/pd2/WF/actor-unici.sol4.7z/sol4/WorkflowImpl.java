package it.polito.pd2.WF.sol4;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlTransient;

import it.polito.pd2.WF.ActionReader;
import it.polito.pd2.WF.ProcessActionReader;
import it.polito.pd2.WF.ProcessReader;
import it.polito.pd2.WF.SimpleActionReader;
import it.polito.pd2.WF.WorkflowReader;
import it.polito.pd2.WF.sol4.jaxb.ProcessType;
import it.polito.pd2.WF.sol4.jaxb.WorkflowType;

@XmlTransient
public class WorkflowImpl extends WorkflowType implements 
		WorkflowReader, Unmarshallable {
	
	@XmlTransient
	private Map<String, ActionImpl> actions;
	@XmlTransient
	private Map<String, List<SimpleActionImpl>> actionRefs;
	@XmlTransient
	private WorkflowMonitorImpl monitor;
	

	public WorkflowImpl() {
		this(null,null);
	}
	
	public WorkflowImpl(WorkflowReader workflow, WorkflowMonitorImpl monitor) {
		actionRefs=new HashMap<String, List<SimpleActionImpl>>();
		actions=new LinkedHashMap<String, ActionImpl>();
		this.monitor=monitor;
		if(workflow==null)
			return;
		
		setName(workflow.getName());
		
		List<ActionImpl> actionList=getActionList();
		List<ProcessType> processList=getProcessList();
		
		//add actions
		for(ActionReader action : workflow.getActions()) {
			if(action instanceof SimpleActionReader)
				actionList.add(new SimpleActionImpl((SimpleActionReader) action,this));
			else
				actionList.add(new ProcessActionImpl((ProcessActionReader)action,this));
		}
		actionsMapping();
		
		//add processes
		for(ProcessReader process : workflow.getProcesses())
			processList.add(new ProcessImpl(process,this));
	}

	public void addActionRef(String key,SimpleActionImpl ref) {
		WorkflowMonitorFactoryImpl.addRef(actionRefs, key, ref);
	}
	
	@Override
	public Set<ActionReader> getActions() {
		return new LinkedHashSet<ActionReader>(actions.values());
	}

	@Override
	public Set<ProcessReader> getProcesses() {
		Set<ProcessReader> set = new LinkedHashSet<ProcessReader>();
		for(ProcessType p : getProcessList())
			set.add((ProcessReader)p);
		return set;
	}

	@Override
	public ActionReader getAction(String name) {
		return actions.get(name);
	}

	@Override
	public void beforeUnmarshal(Object parent) {
		monitor=(WorkflowMonitorImpl) parent;
	}
	
	private void actionsMapping() {
		//map actions
		for(ActionImpl action:getActionList()) {
			String name=action.getName();
			actions.put(name, action);
			//link to SimpleAction.possibleNextAction in actionRefs
			List<SimpleActionImpl> list = actionRefs.get(name);
			if(list==null)
				continue;
			for(SimpleActionImpl simple : list)
				simple.setPossibleNextAction(action);
		}
	}

	@Override
	public void afterUnmarshal(Object parent) {
		actionsMapping();
	}

	public WorkflowMonitorImpl getMonitor() {
		return monitor;
	}

}
